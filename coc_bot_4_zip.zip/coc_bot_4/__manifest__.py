{
    'name': 'Coc_bot',
    'version': '16.0.1.0.0',
    'category': 'Coc_bot/Coc_bot',
    'sequence': '1',
    'installable': True,
    'application': True,
    'depends': ['base'],

    'data': [
        'security/ir.model.access.csv',
        'views/coc_bot_views.xml',

    ],

}
