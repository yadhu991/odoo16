{
    'name': 'Coc_5',
    'version': '16.0.1.0.0',
    'category': 'Coc_5/Coc_5',
    'sequence': '1',
    'installable': True,
    'application': True,
    'depends': ['base'],

    'data': [
        'security/ir.model.access.csv',
        'views/coc_5_views.xml',

    ],

}
